pub fn maintenance_health(equity: i128, margin: i128) -> i128 {
    equity - margin
}
